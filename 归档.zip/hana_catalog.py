# -*- coding: utf-8 -*-
"""SAP HANA catalog helpers (pyodbc).

库对象列表优先使用 PUBLIC 系统目录（与业务常见查询方式一致）：
  PUBLIC.TABLES / PUBLIC.VIEWS / PUBLIC.PROCEDURES / PUBLIC.FUNCTIONS
列信息、参数等仍可用 SYS.*；对象预览仍对真实 schema 执行 SELECT。
"""
from __future__ import annotations

import re
from decimal import Decimal
from datetime import date, datetime, time

# LIKE 子串中的 %、_、\ 转义（配合 ESCAPE '\\'）


def escape_like_contains(substr):
    """将用户输入 B 转为 LIKE 匹配子串（含通配），并转义 \\、%、_。"""
    if substr is None:
        substr = ""
    s = str(substr).replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return "%" + s + "%"


def _quote_ident(part):
    if part is None:
        return ""
    s = str(part).replace('"', "")
    return '"{}"'.format(s)


def qualified_name(schema, name):
    return "{}.{}".format(_quote_ident(schema), _quote_ident(name))


def serialize_value(v):
    if v is None:
        return None
    if isinstance(v, (datetime, date, time)):
        return v.isoformat()
    if isinstance(v, Decimal):
        return float(v)
    if isinstance(v, bytes):
        try:
            return v.decode("utf-8")
        except Exception:
            return repr(v)
    if isinstance(v, (int, float, str, bool)):
        return v
    return str(v)


def rows_to_dicts(cursor, rows):
    cols = [d[0] for d in (cursor.description or [])]
    out = []
    for row in rows:
        d = {}
        for i, c in enumerate(cols):
            d[c] = serialize_value(row[i])
        out.append(d)
    return out


def collect_cursor_result_sets(cursor):
    """
    读取游标上全部结果集（适用于 CALL 后可能有多段结果集的情况）。
    若某段无列元数据则跳过该行集；通过 nextset() 继续直到结束。
    """
    sets = []
    idx = 0
    while True:
        if cursor.description:
            cols = [d[0] for d in cursor.description]
            batch = cursor.fetchall()
            sets.append(
                {
                    "index": idx,
                    "columns": cols,
                    "rows": rows_to_dicts(cursor, batch),
                }
            )
            idx += 1
        try:
            more = cursor.nextset()
        except Exception:
            more = False
        if not more:
            break
    return sets


def connect_pyodbc(dsn, user, password):
    import pyodbc

    conn_str = "DSN={};UID={};PWD={}".format(dsn, user, password)
    return pyodbc.connect(conn_str)


def list_schemas(conn):
    """Schema 列表：优先从 PUBLIC 各目录汇总 DISTINCT SCHEMA_NAME。"""
    cur = conn.cursor()
    try:
        cur.execute(
            """
            SELECT DISTINCT SCHEMA_NAME
            FROM (
                SELECT SCHEMA_NAME FROM PUBLIC.TABLES
                UNION
                SELECT SCHEMA_NAME FROM PUBLIC.VIEWS
                UNION
                SELECT SCHEMA_NAME FROM PUBLIC.PROCEDURES
                UNION
                SELECT SCHEMA_NAME FROM PUBLIC.FUNCTIONS
            ) AS _S
            ORDER BY SCHEMA_NAME
            """
        )
        rows = [r[0] for r in cur.fetchall()]
        cur.close()
        if rows:
            return rows
    except Exception:
        try:
            cur.close()
        except Exception:
            pass
    cur = conn.cursor()
    try:
        cur.execute(
            """
            SELECT SCHEMA_NAME
            FROM SYS.SCHEMAS
            ORDER BY SCHEMA_NAME
            """
        )
        out = [r[0] for r in cur.fetchall()]
        cur.close()
        return out
    except Exception:
        try:
            cur.close()
        except Exception:
            pass
    cur = conn.cursor()
    cur.execute(
        """
        SELECT DISTINCT SCHEMA_NAME
        FROM SYS.TABLES
        ORDER BY SCHEMA_NAME
        """
    )
    rows = [r[0] for r in cur.fetchall()]
    cur.close()
    return rows


def list_tables(conn, schema, search=None):
    """
    从 PUBLIC.TABLES 按账套 SCHEMA_NAME = A 查询基表。
    若提供 search（B），在 TABLE_NAME / COMMENTS 上做 LIKE 子串匹配。
    """
    search = (search or "").strip()
    cur = conn.cursor()
    if search:
        pat = escape_like_contains(search)
        cur.execute(
            """
            SELECT SCHEMA_NAME, TABLE_NAME, COMMENTS, TABLE_TYPE
            FROM PUBLIC.TABLES
            WHERE SCHEMA_NAME = ?
              AND COALESCE(UPPER(TABLE_TYPE), 'TABLE') NOT IN ('VIEW', 'SYNONYM')
              AND (TABLE_NAME LIKE ? ESCAPE '\\' OR IFNULL(COMMENTS, '') LIKE ? ESCAPE '\\')
            ORDER BY TABLE_NAME
            """,
            (schema, pat, pat),
        )
    else:
        cur.execute(
            """
            SELECT SCHEMA_NAME, TABLE_NAME, COMMENTS, TABLE_TYPE
            FROM PUBLIC.TABLES
            WHERE SCHEMA_NAME = ?
              AND COALESCE(UPPER(TABLE_TYPE), 'TABLE') NOT IN ('VIEW', 'SYNONYM')
            ORDER BY TABLE_NAME
            """,
            (schema,),
        )
    rows = rows_to_dicts(cur, cur.fetchall())
    cur.close()
    return rows


def list_views(conn, schema, search=None):
    """
    SELECT SCHEMA_NAME, VIEW_NAME, DEFINITION FROM PUBLIC.VIEWS
    WHERE SCHEMA_NAME = A AND (B 为空或 DEFINITION LIKE '%B%').
    为兼容前端，输出 VIEW_NAME 同时别名为 TABLE_NAME，DEFINITION 别名为 VIEW_DEFINITION。
    """
    search = (search or "").strip()
    cur = conn.cursor()
    if search:
        pat = escape_like_contains(search)
        cur.execute(
            """
            SELECT SCHEMA_NAME, VIEW_NAME, VIEW_NAME AS TABLE_NAME,
                   DEFINITION AS VIEW_DEFINITION
            FROM PUBLIC.VIEWS
            WHERE SCHEMA_NAME = ?
              AND DEFINITION IS NOT NULL
              AND DEFINITION LIKE ? ESCAPE '\\'
            ORDER BY VIEW_NAME
            """,
            (schema, pat),
        )
    else:
        cur.execute(
            """
            SELECT SCHEMA_NAME, VIEW_NAME, VIEW_NAME AS TABLE_NAME,
                   DEFINITION AS VIEW_DEFINITION
            FROM PUBLIC.VIEWS
            WHERE SCHEMA_NAME = ?
            ORDER BY VIEW_NAME
            """,
            (schema,),
        )
    rows = rows_to_dicts(cur, cur.fetchall())
    cur.close()
    return rows


def list_procedures(conn, schema, search=None):
    """
    SELECT SCHEMA_NAME, PROCEDURE_NAME, DEFINITION FROM PUBLIC.PROCEDURES
    WHERE SCHEMA_NAME = A AND (B 为空或 DEFINITION LIKE '%B%').
    """
    search = (search or "").strip()
    cur = conn.cursor()
    if search:
        pat = escape_like_contains(search)
        cur.execute(
            """
            SELECT SCHEMA_NAME, PROCEDURE_NAME, DEFINITION
            FROM PUBLIC.PROCEDURES
            WHERE SCHEMA_NAME = ?
              AND DEFINITION IS NOT NULL
              AND DEFINITION LIKE ? ESCAPE '\\'
            ORDER BY PROCEDURE_NAME
            """,
            (schema, pat),
        )
    else:
        cur.execute(
            """
            SELECT SCHEMA_NAME, PROCEDURE_NAME, DEFINITION
            FROM PUBLIC.PROCEDURES
            WHERE SCHEMA_NAME = ?
            ORDER BY PROCEDURE_NAME
            """,
            (schema,),
        )
    rows = rows_to_dicts(cur, cur.fetchall())
    cur.close()
    return rows


def list_functions(conn, schema, search=None):
    """
    SELECT SCHEMA_NAME, FUNCTION_NAME, DEFINITION FROM PUBLIC.FUNCTIONS
    WHERE SCHEMA_NAME = A AND (B 为空或 DEFINITION LIKE '%B%').
    """
    search = (search or "").strip()
    cur = conn.cursor()
    if search:
        pat = escape_like_contains(search)
        cur.execute(
            """
            SELECT SCHEMA_NAME, FUNCTION_NAME, DEFINITION
            FROM PUBLIC.FUNCTIONS
            WHERE SCHEMA_NAME = ?
              AND DEFINITION IS NOT NULL
              AND DEFINITION LIKE ? ESCAPE '\\'
            ORDER BY FUNCTION_NAME
            """,
            (schema, pat),
        )
    else:
        cur.execute(
            """
            SELECT SCHEMA_NAME, FUNCTION_NAME, DEFINITION
            FROM PUBLIC.FUNCTIONS
            WHERE SCHEMA_NAME = ?
            ORDER BY FUNCTION_NAME
            """,
            (schema,),
        )
    rows = rows_to_dicts(cur, cur.fetchall())
    cur.close()
    return rows


def table_columns(conn, schema, table):
    cur = conn.cursor()
    cur.execute(
        """
        SELECT COLUMN_NAME, DATA_TYPE_NAME, LENGTH, SCALE, IS_NULLABLE, COMMENTS, POSITION
        FROM SYS.TABLE_COLUMNS
        WHERE SCHEMA_NAME = ? AND TABLE_NAME = ?
        ORDER BY POSITION
        """,
        (schema, table),
    )
    rows = rows_to_dicts(cur, cur.fetchall())
    cur.close()
    return rows


def preview_table(conn, schema, table, limit=100):
    qn = qualified_name(schema, table)
    sql = "SELECT * FROM {} LIMIT ?".format(qn)
    cur = conn.cursor()
    cur.execute(sql, (int(limit),))
    rows = rows_to_dicts(cur, cur.fetchall())
    cur.close()
    return rows


def preview_view(conn, schema, view_name, limit=100):
    return preview_table(conn, schema, view_name, limit)


def snapshot_table(conn, schema, table, limit=100):
    """Return count + preview rows for before/after comparison."""
    qn = qualified_name(schema, table)
    cur = conn.cursor()
    try:
        cur.execute("SELECT COUNT(*) FROM {}".format(qn))
        cnt = cur.fetchone()[0]
    except Exception:
        cnt = None
    rows = preview_table(conn, schema, table, limit)
    cur.close()
    return {"count": cnt, "preview": rows, "limit": limit}


def procedure_parameters(conn, schema, name):
    cur = conn.cursor()
    cur.execute(
        """
        SELECT PARAMETER_NAME, DATA_TYPE_NAME, LENGTH, SCALE, POSITION, PARAMETER_TYPE
        FROM SYS.PROCEDURE_PARAMETERS
        WHERE SCHEMA_NAME = ? AND PROCEDURE_NAME = ?
        ORDER BY POSITION
        """,
        (schema, name),
    )
    rows = rows_to_dicts(cur, cur.fetchall())
    cur.close()
    return rows


def function_parameters(conn, schema, name):
    cur = conn.cursor()
    cur.execute(
        """
        SELECT PARAMETER_NAME, DATA_TYPE_NAME, LENGTH, SCALE, POSITION, PARAMETER_TYPE
        FROM SYS.FUNCTION_PARAMETERS
        WHERE SCHEMA_NAME = ? AND FUNCTION_NAME = ?
        ORDER BY POSITION
        """,
        (schema, name),
    )
    rows = rows_to_dicts(cur, cur.fetchall())
    cur.close()
    return rows


def procedure_definition(conn, schema, name):
    """Return procedure definition text if available in catalog."""
    cur = conn.cursor()
    for sql in (
        """
        SELECT DEFINITION FROM PUBLIC.PROCEDURES
        WHERE SCHEMA_NAME = ? AND PROCEDURE_NAME = ?
        """,
        """
        SELECT DEFINITION FROM SYS.PROCEDURES
        WHERE SCHEMA_NAME = ? AND PROCEDURE_NAME = ?
        """,
    ):
        try:
            cur.execute(sql, (schema, name))
            row = cur.fetchone()
            if row and row[0] is not None:
                cur.close()
                return row[0]
        except Exception:
            try:
                cur.close()
            except Exception:
                pass
            cur = conn.cursor()
    try:
        cur.close()
    except Exception:
        pass
    return None


def function_definition(conn, schema, name):
    cur = conn.cursor()
    for sql in (
        """
        SELECT DEFINITION FROM PUBLIC.FUNCTIONS
        WHERE SCHEMA_NAME = ? AND FUNCTION_NAME = ?
        """,
        """
        SELECT DEFINITION FROM SYS.FUNCTIONS
        WHERE SCHEMA_NAME = ? AND FUNCTION_NAME = ?
        """,
    ):
        try:
            cur.execute(sql, (schema, name))
            row = cur.fetchone()
            if row and row[0] is not None:
                cur.close()
                return row[0]
        except Exception:
            try:
                cur.close()
            except Exception:
                pass
            cur = conn.cursor()
    try:
        cur.close()
    except Exception:
        pass
    return None


def validate_catalog_search(search):
    if search is None:
        return ""
    s = str(search).strip()
    if len(s) > 500:
        raise ValueError("关键字过长（最多 500 字符）")
    return s


def validate_schema_name(schema):
    if not schema or not re.match(r"^[A-Za-z0-9_]+$", schema):
        raise ValueError("Invalid schema name")


def validate_object_name(name):
    if not name or not re.match(r"^[A-Za-z0-9_]+$", name):
        raise ValueError("Invalid object name")
