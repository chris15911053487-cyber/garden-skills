"""
SAP HANA + DeepSeek SQL Generator (Python 3.8 + pyodbc + requests)
租户库: NDB, Schema: TEST_HST
自动给表名加 schema 前缀，字段名用双引号
"""

import os
import re
import json
import requests
from datetime import datetime


# =============================================================================
# 1. 配置
# =============================================================================

class Config:
    # HANA 连接配置 (DSN 连 NDB 租户库)
    HANA_DRIVER = "HDBODBC"
    HANA_USER = "SYSTEM"
    HANA_PASSWORD = "!QAZ2wsx"
    HANA_SCHEMA = "TEST_HST"             # SAP B1 账套 schema

    # DeepSeek 配置
    DEEPSEEK_API_KEY = "sk-your-deepseek-api-key-here"
    DEEPSEEK_BASE_URL = "https://api.deepseek.com/v1"
    DEEPSEEK_MODEL = "deepseek-chat"

    TEMPERATURE = 0

    # 安全配置
    DANGEROUS_KEYWORDS = [
        "DROP", "DELETE", "TRUNCATE", 
        "UPDATE", "INSERT", "ALTER", 
        "CREATE", "GRANT", "REVOKE"
    ]


# =============================================================================
# 2. pyodbc 连接 HANA
# =============================================================================

def get_hana_connection(config=None):
    """使用 pyodbc 连接 HANA"""
    import pyodbc

    if config is None:
        config = Config()

    conn_str = "DSN={};UID={};PWD={}".format(
        config.HANA_DRIVER,
        config.HANA_USER,
        config.HANA_PASSWORD
    )

    print("[INFO] Connecting to HANA (NDB)...")
    conn = pyodbc.connect(conn_str)
    print("[INFO] HANA connected successfully!")
    return conn


# =============================================================================
# 3. SQL 处理：自动加 schema 前缀
# =============================================================================

def add_schema_prefix(sql, schema, tables):
    """给 SQL 中的表名加 schema 前缀"""

    # 按表名长度降序排列，避免短表名替换影响长表名
    sorted_tables = sorted(tables, key=len, reverse=True)

    for table in sorted_tables:
        # 匹配独立的表名 (前后不是字母数字下划线)
        pattern = r'(?<![A-Za-z0-9_]){}(?![A-Za-z0-9_])'.format(re.escape(table))
        replacement = '{}.{}'.format(schema, table)
        sql = re.sub(pattern, replacement, sql)

    return sql


def execute_query(conn, sql, config=None):
    """执行 SQL 并返回结果 (自动加 schema 前缀)"""
    if config is None:
        config = Config()

    # 给表名加 schema 前缀
    core_tables = ["OINV", "INV1", "ORDR", "RDR1", "OCRD", "OITM", "OITW", "OWHS", "OACT", "JDT1"]
    sql_with_schema = add_schema_prefix(sql, config.HANA_SCHEMA, core_tables)

    print("[DEBUG] SQL with schema: {}".format(sql_with_schema))

    cursor = conn.cursor()
    cursor.execute(sql_with_schema)

    columns = [desc[0] for desc in cursor.description] if cursor.description else []
    rows = cursor.fetchall()

    result = []
    for row in rows:
        row_dict = {}
        for i, col in enumerate(columns):
            row_dict[col] = row[i]
        result.append(row_dict)

    cursor.close()
    return result


def get_table_schema(conn, table_name, config=None):
    """获取表结构"""
    if config is None:
        config = Config()

    cursor = conn.cursor()

    sql = """
    SELECT COLUMN_NAME, DATA_TYPE_NAME, LENGTH, IS_NULLABLE, COMMENTS
    FROM {}.TABLE_COLUMNS
    WHERE TABLE_NAME = '{}' AND SCHEMA_NAME = '{}'
    ORDER BY POSITION
    """.format(config.HANA_SCHEMA, table_name, config.HANA_SCHEMA)

    cursor.execute(sql)
    columns = [desc[0] for desc in cursor.description]
    rows = cursor.fetchall()

    result = []
    for row in rows:
        row_dict = {}
        for i, col in enumerate(columns):
            row_dict[col] = row[i]
        result.append(row_dict)

    cursor.close()
    return result


def get_sample_data(conn, table_name, limit=2, config=None):
    """获取表样例数据"""
    if config is None:
        config = Config()

    cursor = conn.cursor()

    sql = "SELECT * FROM {}.{} LIMIT {}".format(config.HANA_SCHEMA, table_name, limit)
    cursor.execute(sql)

    columns = [desc[0] for desc in cursor.description]
    rows = cursor.fetchall()

    result = []
    for row in rows:
        row_dict = {}
        for i, col in enumerate(columns):
            row_dict[col] = row[i]
        result.append(row_dict)

    cursor.close()
    return result


# =============================================================================
# 4. 构造表信息
# =============================================================================

def build_table_info(conn, tables, config=None):
    """为 LLM 构造表结构描述"""
    if config is None:
        config = Config()

    info_lines = []

    for table_name in tables:
        info_lines.append("Table: {}.{}".format(config.HANA_SCHEMA, table_name))

        columns = get_table_schema(conn, table_name, config)
        for col in columns:
            col_desc = "  \"{}\" ({}, {})".format(
                col["COLUMN_NAME"],
                col["DATA_TYPE_NAME"],
                "nullable" if col["IS_NULLABLE"] == "TRUE" else "not null"
            )
            if col.get("COMMENTS"):
                col_desc += " -- {}".format(col["COMMENTS"])
            info_lines.append(col_desc)

        try:
            samples = get_sample_data(conn, table_name, 2, config)
            if samples:
                info_lines.append("  Sample rows:")
                for sample in samples:
                    info_lines.append("    {}".format(str(sample)))
        except:
            pass

        info_lines.append("")

    return "\n".join(info_lines)


# =============================================================================
# 5. 直接调用 DeepSeek API
# =============================================================================

def call_deepseek(prompt, config=None):
    """直接调用 DeepSeek API"""
    if config is None:
        config = Config()

    headers = {
        "Authorization": "Bearer {}".format(config.DEEPSEEK_API_KEY),
        "Content-Type": "application/json"
    }

    data = {
        "model": config.DEEPSEEK_MODEL,
        "messages": [
            {"role": "system", "content": "You are an expert SAP Business One SQL consultant. Generate only SQL queries without explanations."},
            {"role": "user", "content": prompt}
        ],
        "temperature": config.TEMPERATURE,
        "max_tokens": 2000
    }

    response = requests.post(
        "{}/chat/completions".format(config.DEEPSEEK_BASE_URL),
        headers=headers,
        json=data,
        timeout=60
    )

    if response.status_code != 200:
        raise Exception("DeepSeek API error: {} - {}".format(response.status_code, response.text))

    result = response.json()
    return result["choices"][0]["message"]["content"]


# =============================================================================
# 6. 核心查询引擎
# =============================================================================

class HANAQueryEngine:
    """HANA + DeepSeek 查询引擎"""

    def __init__(self, config=None):
        if config is None:
            config = Config()
        self.config = config
        self.conn = get_hana_connection(config)

        self.core_tables = ["OINV", "INV1", "ORDR", "RDR1", "OCRD", "OITM", "OITW", "OWHS"]
        self.table_info = self._load_table_info()

    def _load_table_info(self):
        """加载表结构信息"""
        print("[INFO] Loading table schema from {}...".format(self.config.HANA_SCHEMA))
        info = build_table_info(self.conn, self.core_tables, self.config)
        print("[INFO] Table schema loaded.")
        return info

    def query(self, question):
        """执行自然语言查询"""

        try:
            print("[INFO] Generating SQL for: {}".format(question))

            prompt = self._build_prompt(question)
            sql_response = call_deepseek(prompt, self.config)

            sql_clean = self._clean_sql(sql_response)
            print("[INFO] Generated SQL: {}".format(sql_clean))

            self._validate_sql(sql_clean)

            result = execute_query(self.conn, sql_clean, self.config)

            result_str = json.dumps(result, indent=2, ensure_ascii=False, default=str)
            safe_result = self._mask_sensitive(result_str)

            return {
                "question": question,
                "sql": sql_clean,
                "result": safe_result,
                "is_safe": True,
                "timestamp": datetime.now().isoformat()
            }

        except Exception as e:
            return {
                "question": question,
                "error": str(e),
                "is_safe": False,
                "timestamp": datetime.now().isoformat()
            }

    def _build_prompt(self, question):
        """构造 Prompt"""

        return """You are an expert SAP Business One SQL consultant working with SAP HANA database.
Schema: TEST_HST

CRITICAL BUSINESS RULES:
- All column names MUST be enclosed in double quotes: \"DocStatus\", \"CardCode\", \"DocTotal\"
- Table names with schema: TEST_HST.\"OINV\", TEST_HST.\"OCRD\"
- OINV.\"DocStatus\": 'O' = Open, 'C' = Closed
- OINV.\"CANCELED\": 'Y' = Canceled, 'N' = Not Canceled
- OCRD.\"CardType\": 'cCustomer' = Customer, 'cSupplier' = Supplier
- Date format: YYYY-MM-DD
- Always filter \"CANCELED\" = 'N' unless asked for canceled documents
- Use table aliases like T0, T1, T2 for readability
- Use HANA SQL syntax

TABLES AVAILABLE:
{table_info}

Generate ONLY the SQL query (no explanations, no markdown) for this question:
{question}

SQL:""".format(table_info=self.table_info, question=question)

    def _clean_sql(self, sql_response):
        """清理 SQL"""
        sql = sql_response.replace("```sql", "").replace("```", "").strip()
        if sql.upper().startswith("SQL:"):
            sql = sql[4:].strip()
        return sql

    def _validate_sql(self, sql):
        """验证安全性"""
        sql_upper = sql.upper()
        for keyword in self.config.DANGEROUS_KEYWORDS:
            if keyword in sql_upper:
                raise ValueError("SECURITY BLOCKED: keyword '{}' detected".format(keyword))
        if not sql.strip().upper().startswith("SELECT"):
            raise ValueError("SECURITY BLOCKED: only SELECT allowed")

    def _mask_sensitive(self, result):
        """脱敏"""
        result = re.sub(r'(\d{3})\d{4}(\d{4})', r'****', result)
        result = re.sub(r'(\d{6})\d{8}(\d{4})', r'********', result)
        return result

    def close(self):
        """关闭连接"""
        if self.conn:
            self.conn.close()
            print("[INFO] HANA connection closed.")


# =============================================================================
# 7. 测试
# =============================================================================

def demo():
    """演示"""

    engine = HANAQueryEngine()

    print("\n" + "=" * 60)
    print("Test 1: Query open sales invoices")
    print("=" * 60)

    result = engine.query("Query all open sales invoices with customer code and total amount")
    print("SQL:", result.get("sql", "N/A"))
    print("Result:", result.get("result", result.get("error")))

    print("\n" + "=" * 60)
    print("Test 2: Query customer balance")
    print("=" * 60)

    result = engine.query("Find customers with balance greater than 10000")
    print("SQL:", result.get("sql", "N/A"))
    print("Result:", result.get("result", result.get("error")))

    engine.close()


if __name__ == "__main__":
    print("SAP HANA + DeepSeek (Python 3.8 + pyodbc + requests)")
    print("=" * 60)
    print("Config:")
    print("  HANA DSN: HDBODBC (NDB tenant)")
    print("  HANA Schema: {}".format(Config.HANA_SCHEMA))
    print("  HANA User: {}".format(Config.HANA_USER))
    print("  DeepSeek Model: {}".format(Config.DEEPSEEK_MODEL))
    print()
    print("Before running:")
    print("1. Update DEEPSEEK_API_KEY in Config class")
    print("2. pip install pyodbc requests")
    print()

    demo()
