# -*- coding: utf-8 -*-
"""
HANA 浏览器 + LLM 配置（Flask）
连接方式与 erp_query_py38_final.py 一致：pyodbc + DSN=...;UID=...;PWD=...
Windows：已安装 HANA ODBC 并配置好 DSN 后，在项目目录执行:
  python -m venv .venv
  .venv\\Scripts\\activate
  pip install -r requirements.txt
  python app.py
"""
from __future__ import annotations

import json
import os
import copy
import requests
from flask import Flask, jsonify, render_template, request

import hana_catalog as hc

APP_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(APP_DIR, "config.json")

DEFAULT_CONFIG = {
    "hana": {
        "dsn": "HDBODBC",
        "user": "",
        "password": "",
        "default_schema": "",
    },
    "llm": {
        "api_key": "",
        "base_url": "https://api.deepseek.com/v1",
        "model": "deepseek-chat",
        "temperature": 0,
    },
}


def deep_merge(base, override):
    out = copy.deepcopy(base)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def load_config():
    if not os.path.isfile(CONFIG_PATH):
        return copy.deepcopy(DEFAULT_CONFIG)
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)
    return deep_merge(DEFAULT_CONFIG, data)


def save_config(cfg):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)


def mask_config_for_client(cfg):
    """Do not send raw secrets to browser."""
    c = copy.deepcopy(cfg)
    if c["hana"].get("password"):
        c["hana"]["password"] = ""
        c["hana"]["password_set"] = True
    else:
        c["hana"]["password_set"] = False
    if c["llm"].get("api_key"):
        c["llm"]["api_key"] = ""
        c["llm"]["api_key_set"] = True
    else:
        c["llm"]["api_key_set"] = False
    return c


def merge_post_config(existing, posted):
    """Empty password / api_key means keep previous."""
    merged = deep_merge(existing, posted)
    h = posted.get("hana") or {}
    if h.get("password") in (None, ""):
        merged["hana"]["password"] = existing["hana"].get("password", "")
    l = posted.get("llm") or {}
    if l.get("api_key") in (None, ""):
        merged["llm"]["api_key"] = existing["llm"].get("api_key", "")
    return merged


def hana_connect_from_cfg(cfg):
    h = cfg["hana"]
    dsn = (h.get("dsn") or "").strip()
    user = (h.get("user") or "").strip()
    pwd = h.get("password") or ""
    if not dsn or not user:
        raise ValueError("HANA DSN 与用户名为必填项")
    return hc.connect_pyodbc(dsn, user, pwd)


def llm_chat_test(cfg):
    l = cfg["llm"]
    key = (l.get("api_key") or "").strip()
    base = (l.get("base_url") or "").strip().rstrip("/")
    model = (l.get("model") or "").strip()
    temp = l.get("temperature", 0)
    if not key:
        raise ValueError("LLM API Key 未配置")
    if not base:
        raise ValueError("LLM Base URL 未配置")
    url = "{}/chat/completions".format(base)
    headers = {
        "Authorization": "Bearer {}".format(key),
        "Content-Type": "application/json",
    }
    data = {
        "model": model,
        "messages": [{"role": "user", "content": "Reply with exactly: OK"}],
        "temperature": float(temp) if temp is not None else 0,
        "max_tokens": 8,
    }
    r = requests.post(url, headers=headers, json=data, timeout=60)
    if r.status_code != 200:
        raise RuntimeError("HTTP {}: {}".format(r.status_code, r.text[:500]))
    body = r.json()
    msg = body.get("choices", [{}])[0].get("message", {}).get("content", "")
    return {"ok": True, "sample_reply": (msg or "")[:200]}


def llm_chat(cfg, messages, max_tokens=2000, temperature=None):
    """通用 LLM Chat 调用，返回文本回复。"""
    l = cfg["llm"]
    key = (l.get("api_key") or "").strip()
    base = (l.get("base_url") or "").strip().rstrip("/")
    model = (l.get("model") or "").strip()
    temp = temperature if temperature is not None else l.get("temperature", 0)
    if not key:
        raise ValueError("LLM API Key 未配置")
    if not base:
        raise ValueError("LLM Base URL 未配置")
    url = "{}/chat/completions".format(base)
    headers = {
        "Authorization": "Bearer {}".format(key),
        "Content-Type": "application/json",
    }
    data = {
        "model": model,
        "messages": messages,
        "temperature": float(temp) if temp is not None else 0,
        "max_tokens": int(max_tokens),
    }
    r = requests.post(url, headers=headers, json=data, timeout=120)
    if r.status_code != 200:
        raise RuntimeError("HTTP {}: {}".format(r.status_code, r.text[:800]))
    body = r.json()
    msg = body.get("choices", [{}])[0].get("message", {}).get("content", "")
    return (msg or "").strip()


# 供「HTTP API 一览」与 GET /api/meta/endpoints 使用；新增路由时请同步更新本表。
HTTP_API_DOCS = [
    (
        "GET",
        "/procedure-exec",
        "独立 HTML 页面：?schema=&name= 执行存储过程、监视表快照；非 JSON API。",
    ),
    (
        "GET",
        "/api/meta/endpoints",
        "返回本应用暴露的 /api 清单、说明与条数（本页数据源）。",
    ),
    ("GET", "/api/config", "读取配置（密码与 API Key 不回显，仅标记是否已设置）。"),
    ("POST", "/api/config", "保存配置；hana.password / llm.api_key 留空表示保留原值。"),
    ("POST", "/api/hana/test", "测试 HANA 连接；请求体可带临时 hana（及可选 llm）覆盖。"),
    ("POST", "/api/llm/test", "测试大模型 Chat Completions 极小请求。"),
    ("GET", "/api/schemas", "当前配置下的 Schema 列表。"),
    ("GET", "/api/catalog/tables", "表列表；query: schema（必填）, search（可选）。"),
    ("GET", "/api/catalog/views", "视图列表；query: schema, search。"),
    ("GET", "/api/catalog/procedures", "存储过程列表；query: schema, search。"),
    ("GET", "/api/catalog/functions", "函数列表；query: schema, search。"),
    (
        "GET",
        "/api/catalog/table/<schema>/<name>/columns",
        "指定表的列信息。",
    ),
    (
        "GET",
        "/api/catalog/table/<schema>/<name>/preview",
        "表数据预览；query: limit（1–500，默认 100）。",
    ),
    (
        "GET",
        "/api/catalog/view/<schema>/<name>/preview",
        "视图数据预览；query: limit。",
    ),
    (
        "GET",
        "/api/catalog/procedure/<schema>/<name>",
        "存储过程参数与定义（若目录提供）。",
    ),
    (
        "GET",
        "/api/catalog/function/<schema>/<name>",
        "函数参数与定义（若目录提供）。",
    ),
    (
        "POST",
        "/api/llm/table_chat",
        "表样本 + 列结构与 LLM 对话总结；JSON: schema, table, question, columns, preview。",
    ),
    (
        "POST",
        "/api/llm/analyze_procedure",
        "LLM 分析存储过程结构；JSON: schema, name, definition, parameters。",
    ),
    (
        "POST",
        "/api/llm/procedure_chat",
        "与存储过程对话（自然语言执行建议、逻辑解释、参数判断）；JSON: schema, name, definition, parameters, messages[], last_execution。",
    ),
    (
        "POST",
        "/api/hana/execute_procedure",
        "执行 CALL 并可选关键词验证；支持 watch_tables 做前后快照。JSON: schema, name, args[], expected, watch_tables[]。",
    ),
]


app = Flask(__name__)


@app.before_request
def _cors_preflight():
    """允许从 file:// 或另一端口打开的静态页调用本机 API（开发/误操作场景）。"""
    if request.method == "OPTIONS" and request.path.startswith("/api/"):
        r = app.make_response("", 204)
        r.headers["Access-Control-Allow-Origin"] = "*"
        r.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
        r.headers["Access-Control-Allow-Headers"] = "Content-Type"
        return r
    return None


@app.after_request
def _cors_api(resp):
    if request.path.startswith("/api/"):
        resp.headers["Access-Control-Allow-Origin"] = "*"
        resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
        resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return resp


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/procedure-exec")
def procedure_exec_page():
    """独立页面：存储过程执行与验证（query: schema, name）。"""
    return render_template("procedure_exec.html")


@app.route("/api/meta/endpoints", methods=["GET"])
def api_meta_endpoints():
    items = [
        {"method": m, "path": p, "description": d} for m, p, d in HTTP_API_DOCS
    ]
    return jsonify({"ok": True, "count": len(items), "items": items})


@app.route("/api/config", methods=["GET"])
def api_config_get():
    cfg = load_config()
    return jsonify(mask_config_for_client(cfg))


@app.route("/api/config", methods=["POST"])
def api_config_post():
    posted = request.get_json(force=True, silent=True) or {}
    existing = load_config()
    merged = merge_post_config(existing, posted)
    save_config(merged)
    return jsonify({"ok": True, "config": mask_config_for_client(merged)})


@app.route("/api/hana/test", methods=["POST"])
def api_hana_test():
    body = request.get_json(force=True, silent=True) or {}
    cfg = load_config()
    if body:
        cfg = merge_post_config(cfg, body)
    conn = None
    try:
        conn = hana_connect_from_cfg(cfg)
        cur = conn.cursor()
        cur.execute("SELECT CURRENT_USER FROM DUMMY")
        row = cur.fetchone()
        cur.close()
        return jsonify({"ok": True, "current_user": row[0] if row else None})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass


@app.route("/api/llm/test", methods=["POST"])
def api_llm_test():
    body = request.get_json(force=True, silent=True) or {}
    cfg = load_config()
    if body:
        cfg = merge_post_config(cfg, body)
    try:
        result = llm_chat_test(cfg)
        return jsonify(result)
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400


@app.route("/api/schemas", methods=["GET"])
def api_schemas():
    cfg = load_config()
    conn = None
    try:
        conn = hana_connect_from_cfg(cfg)
        names = hc.list_schemas(conn)
        return jsonify({"ok": True, "schemas": names})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass


def _with_hana(fn):
    cfg = load_config()
    conn = None
    try:
        conn = hana_connect_from_cfg(cfg)
        return fn(conn, cfg)
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass


@app.route("/api/catalog/tables", methods=["GET"])
def api_tables():
    schema = request.args.get("schema", "").strip()
    try:
        hc.validate_schema_name(schema)
        search = hc.validate_catalog_search(request.args.get("search", ""))
    except ValueError as e:
        return jsonify({"ok": False, "error": str(e)}), 400

    def work(conn, _cfg):
        rows = hc.list_tables(conn, schema, search)
        return jsonify({"ok": True, "items": rows})

    return _with_hana(work)


@app.route("/api/catalog/views", methods=["GET"])
def api_views():
    schema = request.args.get("schema", "").strip()
    try:
        hc.validate_schema_name(schema)
        search = hc.validate_catalog_search(request.args.get("search", ""))
    except ValueError as e:
        return jsonify({"ok": False, "error": str(e)}), 400

    def work(conn, _cfg):
        rows = hc.list_views(conn, schema, search)
        return jsonify({"ok": True, "items": rows})

    return _with_hana(work)


@app.route("/api/catalog/procedures", methods=["GET"])
def api_procedures():
    schema = request.args.get("schema", "").strip()
    try:
        hc.validate_schema_name(schema)
        search = hc.validate_catalog_search(request.args.get("search", ""))
    except ValueError as e:
        return jsonify({"ok": False, "error": str(e)}), 400

    def work(conn, _cfg):
        rows = hc.list_procedures(conn, schema, search)
        return jsonify({"ok": True, "items": rows})

    return _with_hana(work)


@app.route("/api/catalog/functions", methods=["GET"])
def api_functions():
    schema = request.args.get("schema", "").strip()
    try:
        hc.validate_schema_name(schema)
        search = hc.validate_catalog_search(request.args.get("search", ""))
    except ValueError as e:
        return jsonify({"ok": False, "error": str(e)}), 400

    def work(conn, _cfg):
        rows = hc.list_functions(conn, schema, search)
        return jsonify({"ok": True, "items": rows})

    return _with_hana(work)


@app.route("/api/catalog/table/<schema>/<name>/columns", methods=["GET"])
def api_table_columns(schema, name):
    try:
        hc.validate_schema_name(schema)
        hc.validate_object_name(name)
    except ValueError as e:
        return jsonify({"ok": False, "error": str(e)}), 400

    def work(conn, _cfg):
        rows = hc.table_columns(conn, schema, name)
        return jsonify({"ok": True, "columns": rows})

    return _with_hana(work)


@app.route("/api/catalog/table/<schema>/<name>/preview", methods=["GET"])
def api_table_preview(schema, name):
    try:
        hc.validate_schema_name(schema)
        hc.validate_object_name(name)
    except ValueError as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    limit = request.args.get("limit", "100")
    try:
        lim = max(1, min(500, int(limit)))
    except ValueError:
        lim = 100

    def work(conn, _cfg):
        rows = hc.preview_table(conn, schema, name, lim)
        return jsonify({"ok": True, "rows": rows, "limit": lim})

    return _with_hana(work)


@app.route("/api/catalog/view/<schema>/<name>/preview", methods=["GET"])
def api_view_preview(schema, name):
    try:
        hc.validate_schema_name(schema)
        hc.validate_object_name(name)
    except ValueError as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    limit = request.args.get("limit", "100")
    try:
        lim = max(1, min(500, int(limit)))
    except ValueError:
        lim = 100

    def work(conn, _cfg):
        rows = hc.preview_view(conn, schema, name, lim)
        return jsonify({"ok": True, "rows": rows, "limit": lim})

    return _with_hana(work)


@app.route("/api/catalog/procedure/<schema>/<name>", methods=["GET"])
def api_procedure_detail(schema, name):
    try:
        hc.validate_schema_name(schema)
        hc.validate_object_name(name)
    except ValueError as e:
        return jsonify({"ok": False, "error": str(e)}), 400

    def work(conn, _cfg):
        params = hc.procedure_parameters(conn, schema, name)
        definition = hc.procedure_definition(conn, schema, name)
        return jsonify(
            {"ok": True, "parameters": params, "definition": definition}
        )

    return _with_hana(work)


@app.route("/api/catalog/function/<schema>/<name>", methods=["GET"])
def api_function_detail(schema, name):
    try:
        hc.validate_schema_name(schema)
        hc.validate_object_name(name)
    except ValueError as e:
        return jsonify({"ok": False, "error": str(e)}), 400

    def work(conn, _cfg):
        params = hc.function_parameters(conn, schema, name)
        definition = hc.function_definition(conn, schema, name)
        return jsonify(
            {"ok": True, "parameters": params, "definition": definition}
        )

    return _with_hana(work)


@app.route("/api/llm/table_chat", methods=["POST"])
def api_llm_table_chat():
    body = request.get_json(force=True, silent=True) or {}
    schema = (body.get("schema") or "").strip()
    table = (body.get("table") or "").strip()
    question = (body.get("question") or "").strip()
    preview_rows = body.get("preview") or []
    columns = body.get("columns") or []
    if not schema or not table or not question:
        return jsonify({"ok": False, "error": "schema、table、question 必填"}), 400
    try:
        hc.validate_schema_name(schema)
        hc.validate_object_name(table)
    except ValueError as e:
        return jsonify({"ok": False, "error": str(e)}), 400

    cfg = load_config()
    try:
        # 构造提示
        sys_prompt = (
            "你是一个专业的 SAP HANA 数据分析师。"
            "用户会提供表结构（列信息）和最多 100 行样本数据。"
            "请根据这些信息，用中文简洁回答用户问题，并给出数据洞察或总结。"
            "如果数据不足以回答，请明确指出。"
        )
        user_content = (
            f"表：{schema}.{table}\n"
            f"列结构：{columns}\n"
            f"样本数据（前 {len(preview_rows)} 行）：\n{preview_rows}\n\n"
            f"用户问题：{question}"
        )
        messages = [
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": user_content},
        ]
        reply = llm_chat(cfg, messages, max_tokens=1500)
        return jsonify({"ok": True, "reply": reply})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400


@app.route("/api/llm/analyze_procedure", methods=["POST"])
def api_llm_analyze_procedure():
    body = request.get_json(force=True, silent=True) or {}
    schema = (body.get("schema") or "").strip()
    name = (body.get("name") or "").strip()
    definition = body.get("definition") or ""
    parameters = body.get("parameters") or []
    if not schema or not name:
        return jsonify({"ok": False, "error": "schema 和 name 必填"}), 400
    try:
        hc.validate_schema_name(schema)
        hc.validate_object_name(name)
    except ValueError as e:
        return jsonify({"ok": False, "error": str(e)}), 400

    cfg = load_config()
    try:
        sys_prompt = (
            "你是一个资深的 SAP HANA 存储过程代码审查专家。"
            "请用中文结构化输出以下内容："
            "1. 过程概览（输入/输出参数、主要功能）；"
            "2. 核心逻辑与分支（关键 IF/CASE/LOOP）；"
            "3. 影响的表/视图及操作类型（SELECT/INSERT/UPDATE/DELETE）；"
            "4. 潜在风险（性能、事务、权限、数据一致性）；"
            "5. 建议改进点。"
        )
        user_content = (
            f"存储过程：{schema}.{name}\n"
            f"参数列表：{parameters}\n"
            f"定义正文（可能被截断）：\n{definition[:8000] if definition else '（未提供正文）'}\n\n"
            "请按上述 5 个方面输出结构化分析。"
        )
        messages = [
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": user_content},
        ]
        reply = llm_chat(cfg, messages, max_tokens=2000)
        return jsonify({"ok": True, "analysis": reply})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400


@app.route("/api/llm/procedure_chat", methods=["POST"])
def api_llm_procedure_chat():
    """与存储过程对话：自然语言驱动的参数建议、执行意图、逻辑解释、AI 判断。"""
    body = request.get_json(force=True, silent=True) or {}
    schema = (body.get("schema") or "").strip()
    name = (body.get("name") or "").strip()
    definition = body.get("definition") or ""
    parameters = body.get("parameters") or []
    messages = body.get("messages") or []
    last_execution = body.get("last_execution") or {}
    if not schema or not name:
        return jsonify({"ok": False, "error": "schema 和 name 必填"}), 400
    try:
        hc.validate_schema_name(schema)
        hc.validate_object_name(name)
    except ValueError as e:
        return jsonify({"ok": False, "error": str(e)}), 400

    cfg = load_config()
    try:
        sys_prompt = (
            f"你是 SAP HANA 存储过程 {schema}.{name} 的专业智能助手。\n"
            "精通过程参数、定义逻辑、分支、影响的表和数据变更。\n"
            f"过程定义（可能被截断）：\n{definition[:6500] if definition else '（未提供定义）'}\n\n"
            f"参数列表：{parameters}\n"
            f"上一次执行上下文（可选）：{last_execution}\n\n"
            "用户用中文自然语言提问或下指令。你需要：\n"
            "1. 直接、简洁、专业地用中文回复。\n"
            "2. 若用户要求执行、给出参数值或让 AI 判断参数：提取参数，建议具体 args 列表，并在回复末尾标注 [建议执行] args=[...] \n"
            "3. 若用户询问某个字段、分支、WHERE 条件、调用逻辑等：引用定义原文解释清楚。\n"
            "4. 支持追问上一次执行结果或快照变化。\n"
            "5. 永远不要真正执行 CALL，只给出建议和解释。回复控制在 400 字内。"
        )
        full_messages = [{"role": "system", "content": sys_prompt}] + messages
        reply = llm_chat(cfg, full_messages, max_tokens=2200, temperature=0.2)
        return jsonify({"ok": True, "reply": reply})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400


@app.route("/api/hana/execute_procedure", methods=["POST"])
def api_execute_procedure():
    """
    执行存储过程并返回结果。
    注意：HANA 存储过程可能内部有 COMMIT，无法完全回滚。
    建议仅在测试库使用，或过程本身支持事务控制。
    """
    body = request.get_json(force=True, silent=True) or {}
    schema = (body.get("schema") or "").strip()
    name = (body.get("name") or "").strip()
    args = body.get("args") or []  # 位置参数列表
    expected = (body.get("expected") or "").strip()
    watch_tables = body.get("watch_tables") or []  # e.g. ["TABLE1", "SCHEMA.TABLE2"]
    if not schema or not name:
        return jsonify({"ok": False, "error": "schema 和 name 必填"}), 400
    try:
        hc.validate_schema_name(schema)
        hc.validate_object_name(name)
    except ValueError as e:
        return jsonify({"ok": False, "error": str(e)}), 400

    cfg = load_config()
    conn = None
    try:
        conn = hana_connect_from_cfg(cfg)

        # 1. Before snapshots if watch_tables provided
        snapshots = {}
        for wt in watch_tables:
            wt = str(wt).strip()
            if not wt:
                continue
            # support "SCHEMA.TABLE" or just "TABLE" (use current schema)
            if "." in wt:
                ws, wtbl = wt.split(".", 1)
            else:
                ws, wtbl = schema, wt
            try:
                hc.validate_schema_name(ws)
                hc.validate_object_name(wtbl)
                snapshots[wt] = {
                    "before": hc.snapshot_table(conn, ws, wtbl, 100),
                    "after": None,
                }
            except Exception as e:
                snapshots[wt] = {"error": str(e)}

        cur = conn.cursor()
        # 2. 执行 CALL
        placeholders = ",".join(["?"] * len(args))
        call_sql = "CALL {}({})".format(hc.qualified_name(schema, name), placeholders)
        cur.execute(call_sql, args)
        result_sets = []
        try:
            result_sets = hc.collect_cursor_result_sets(cur)
        except Exception:
            result_sets = []
        try:
            rowcount = cur.rowcount
        except Exception:
            rowcount = None
        cur.close()

        # 3. After snapshots
        for wt in list(snapshots.keys()):
            if "error" in snapshots[wt]:
                continue
            if "." in wt:
                ws, wtbl = wt.split(".", 1)
            else:
                ws, wtbl = schema, wt
            try:
                snapshots[wt]["after"] = hc.snapshot_table(conn, ws, wtbl, 100)
            except Exception as e:
                snapshots[wt]["after_error"] = str(e)

        # 兼容旧字段：优先取第一个非空结果集的行；否则为第一段（可能为空）
        rows = []
        for rs in result_sets:
            if rs.get("rows"):
                rows = rs["rows"]
                break
        if not rows and result_sets:
            rows = result_sets[0].get("rows") or []

        # Build richer result_text (include snapshot summary if any)
        parts = []
        for rs in result_sets:
            parts.append(
                "[结果集 {}] 列: {}\n行数: {}".format(
                    rs["index"], rs.get("columns"), len(rs.get("rows") or [])
                )
            )
        if snapshots:
            parts.append("\n[数据快照] 监视表: " + ", ".join(snapshots.keys()))
        result_text = "\n".join(parts) if parts else "[]"
        parts = []
        for rs in result_sets:
            parts.append(
                "[结果集 {}] 列: {}\n{}".format(
                    rs["index"],
                    rs.get("columns"),
                    rs.get("rows"),
                )
            )
        result_text = "\n\n".join(parts) if parts else "[]"
        result_text = result_text[:4000]

        empty_hint = None
        total_rows = sum(len(rs.get("rows") or []) for rs in result_sets)
        if not result_sets or total_rows == 0:
            empty_hint = (
                "未从 ODBC 游标读到任何结果集行。这在 HANA 上很常见：过程可能只写库、只通过 "
                "OUT/INOUT 标量或表参数返回值，或客户端驱动不暴露匿名结果集。"
                " 可在 HANA Studio / DBeaver 用相同 CALL 与参数核对；若需 Web 端看到 OUT 表，"
                "需改为包装 SQL 或扩展本接口以绑定输出参数。"
            )

        match = False
        if expected:
            hay = result_text.lower()
            match = expected.lower() in hay or expected in result_text

        return jsonify({
            "ok": True,
            "result_rows": rows,
            "result_sets": result_sets,
            "result_text": result_text,
            "rowcount": rowcount,
            "expected": expected,
            "match": match,
            "empty_hint": empty_hint,
            "snapshots": snapshots,
            "warning": "注意：部分 HANA 存储过程内部可能已 COMMIT，无法完全回滚。请确保在测试环境执行。",
        })
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass


if __name__ == "__main__":
    host = os.environ.get("FLASK_RUN_HOST", "0.0.0.0")
    port = int(os.environ.get("FLASK_RUN_PORT", "5050"))
    app.run(host=host, port=port, debug=False)
