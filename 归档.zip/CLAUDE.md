# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 项目概述

Flask Web 应用，用于浏览 SAP HANA 数据库目录对象（表、视图、存储过程、函数）并配置 OpenAI 兼容的大模型连接。通过 Windows ODBC DSN 连接 HANA。

## 启动命令

```bash
# 安装依赖
pip install -r requirements.txt

# 启动服务（默认 http://127.0.0.1:5050）
python app.py

# 自定义主机/端口
FLASK_RUN_HOST=127.0.0.1 FLASK_RUN_PORT=8080 python app.py
```

Windows 上可直接双击 `run_windows.bat`，自动创建 `.venv`、安装依赖并启动。

## 架构

```
app.py                  # Flask 主应用：路由、配置管理、HANA/LLM API
hana_catalog.py         # HANA 元数据查询与数据预览（pyodbc）
templates/
  index.html            # 主界面 SPA：配置、目录浏览、API 一览
  procedure_exec.html   # 存储过程执行与验证独立页面
erp_query_py38_final.py # 独立 CLI 脚本（NL2SQL 引擎），未集成到 Web 服务
```

### 关键设计

- **目录查询分层**：对象列表用 `PUBLIC.TABLES/VIEWS/PROCEDURES/FUNCTIONS`；详细元数据（列、参数）用 `SYS.TABLE_COLUMNS`、`SYS.PROCEDURE_PARAMETERS` 等。
- **配置持久化**：`config.json`（已 gitignore），密码和 API Key 在 GET /api/config 时仅返回 `password_set`/`api_key_set` 标记，不返回原文。POST 时空值表示保留已保存的值。
- **CORS**：所有 `/api/*` 响应自动添加 `Access-Control-Allow-Origin: *`，支持从 `file://` 协议打开的静态页面调用。
- **输入验证**：schema 和对象名通过 `^[A-Za-z0-9_]+$` 正则校验；LIKE 搜索中的 `%`、`_`、`\` 被转义，配合 `ESCAPE '\\'`。
- **连接管理**：`app.py` 中 `_with_hana(fn)` 辅助函数统一处理连接的创建/关闭/异常。
- **`erp_query_py38_final.py`** 是独立的命令行工具，拥有自己的 HANA 连接、表结构加载和 DeepSeek API 调用逻辑，与 Flask 应用互不依赖。

## API 路由模式

所有 `/api/catalog/*` 路由遵循相同模式：前端验证参数 → `_with_hana(work)` 包装 → 调用 `hana_catalog` 对应函数。新增目录接口时沿用此模式。

`HTTP_API_DOCS` 列表（app.py:161）是 `/api/meta/endpoints` 的数据源，新增路由时需同步更新。

## 注意事项

- 此项目**仅限 Windows** 运行，依赖系统级 ODBC DSN 配置。
- `config.json` 含敏感信息，不可提交到版本控制。
- 存储过程执行可能包含 `COMMIT`，无法回滚，`/api/hana/execute_procedure` 有警告提示。
- 数据预览是真实 `SELECT`，应使用只读权限账号。
