@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo [1/3] 使用虚拟环境 .venv（若不存在则创建）...
if not exist ".venv\Scripts\python.exe" (
  python -m venv .venv
  if errorlevel 1 (
    echo 错误: 无法创建虚拟环境，请确认已安装 Python 并加入 PATH。
    pause
    exit /b 1
  )
)

echo [2/3] 安装依赖 requirements.txt ...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\pip.exe" install -r requirements.txt
if errorlevel 1 (
  echo 错误: pip 安装失败。
  pause
  exit /b 1
)

echo [3/3] 启动服务，浏览器访问 http://127.0.0.1:5050
".venv\Scripts\python.exe" app.py
pause
