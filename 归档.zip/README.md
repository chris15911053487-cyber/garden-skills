# HANA 目录浏览器与 LLM 配置

本仓库在原有命令行示例 `erp_query_py38_final.py`（SAP HANA + pyodbc + 大模型）之外，增加了一个 **基于浏览器的配置与元数据浏览界面**，便于在 Windows 服务器上通过已配置好的 **ODBC DSN** 管理连接与大模型参数，并查看库中的表、视图、存储过程与函数。

---

## 已实现功能

### 1. Web 界面（`app.py` + `templates/index.html`）

- **连接与模型配置**页  
  - **HANA**：DSN 名称、用户名、密码、默认 Schema（可选）。  
  - **大模型**：OpenAI 兼容的 Base URL、模型名、API Key、`temperature`。  
  - **测试 HANA**：使用当前表单内容（或已保存配置）发起连接，返回 `CURRENT_USER`。  
  - **测试 LLM**：调用 `{base_url}/chat/completions` 做极小请求，确认密钥与地址可用。  
  - **保存配置**：将设置写入项目目录下的 `config.json`；密码与 API Key **留空表示保留上次已保存的值**（避免每次保存都要重新输入）。

- **库对象浏览**页  
  - **Schema（A）** 下拉：优先汇总 `PUBLIC` 四张目录表中的 `SCHEMA_NAME`。  
  - 可选 **关键字（B）**：与账套组合筛选——过程/视图/函数在 `DEFINITION` 中子串匹配；表在 `TABLE_NAME` / `COMMENTS` 中子串匹配（与 `PUBLIC` 固定查询方式一致）。  
  - 四类对象切换：**表**、**视图**、**存储过程**、**函数**（列表均来自 `PUBLIC.TABLES` / `PUBLIC.VIEWS` / `PUBLIC.PROCEDURES` / `PUBLIC.FUNCTIONS`）。  
  - 左侧列表展示名称与简要信息；点击后在右侧展示：  
    - **表**：列信息（`SYS.TABLE_COLUMNS`）+ **数据预览**（`SELECT * ... LIMIT`，默认最多 100 行，可调至 500）。  
    - **视图**：展示 `PUBLIC.VIEWS` 中的定义文本 + **数据预览**。  
    - **存储过程 / 函数**：**参数列表**（`SYS.PROCEDURE_PARAMETERS` / `SYS.FUNCTION_PARAMETERS`）；**定义**优先读 `PUBLIC`，若无再读 `SYS`。

### 2. HANA 连接方式（与案例一致）

- 仅使用 **pyodbc + ODBC DSN**，连接串形式：  
  `DSN={dsn};UID={user};PWD={password}`  
- 与 `erp_query_py38_final.py` 中的 `get_hana_connection` 思路一致；**不要求**在本程序中再安装 HANA 驱动，前提是 Windows 上已通过 SAP HANA Client / ODBC 配好 DSN。

### 3. 后端模块（`hana_catalog.py`）

- **库对象列表**固定从 **`PUBLIC`** 系统目录查询（与常见账套检索方式一致）：  
  - 表：`PUBLIC.TABLES`，`SCHEMA_NAME = A`，排除 `VIEW` / `SYNONYM`；关键字 **B** 在 `TABLE_NAME`、`COMMENTS` 上 `LIKE` 子串匹配。  
  - 视图：`PUBLIC.VIEWS`，`SCHEMA_NAME = A`，关键字 **B** 在 `DEFINITION` 上 `LIKE`（等价于你提供的「在 A 中查定义含 B」）。  
  - 存储过程 / 函数：`PUBLIC.PROCEDURES`、`PUBLIC.FUNCTIONS`，条件同上。  
  - `LIKE` 对用户输入中的 `%`、`_`、`\` 做了转义，并配合 `ESCAPE '\\'`，降低误用通配符风险。  
- **Schema 下拉列表**：优先 `PUBLIC` 下四张目录表的 `SCHEMA_NAME` 去重并集；失败时回退 `SYS.SCHEMAS` / `SYS.TABLES`。  
- **列信息、参数、预览**：仍使用 `SYS.TABLE_COLUMNS`、`SYS.PROCEDURE_PARAMETERS` 等对真实对象执行 `SELECT`；过程/函数定义读取优先 **`PUBLIC`**，再回退 **`SYS`**。

### 4. 工程与依赖

- **`requirements.txt`**：`flask`、`pyodbc`、`requests`。  
- **`.gitignore`**：忽略 `config.json`、虚拟环境等，避免将密钥提交到版本库。

### 5. 未包含（与示例脚本的关系）

- **`erp_query_py38_final.py`** 仍为独立的「自然语言 → 生成 SQL → 执行」演示脚本，**未**并入本 Web 服务。  
- Web 端当前聚焦 **配置 + 元数据浏览 + LLM 连通性测试**，不包含对示例里「NL2SQL 引擎」的在线封装；若需要可在后续将 `HANAQueryEngine` 以 API 形式挂接到同一应用。

---

## 项目结构

| 文件 / 目录 | 说明 |
|-------------|------|
| `app.py` | Flask 应用：页面路由、配置读写、HANA/LLM 测试与目录 REST API |
| `hana_catalog.py` | HANA 元数据与预览查询 |
| `templates/index.html` | 单页前端（配置 + 浏览） |
| `config.json` | 运行后生成，保存敏感信息，勿入库 |
| `erp_query_py38_final.py` | 原有 HANA + DeepSeek 命令行示例 |
| `run_windows.bat` | Windows 下一键创建 `.venv`、安装依赖并启动 `app.py` |
| `requirements.txt` | Python 依赖 |

---

## Windows 上运行

前提：本机或服务器 **已安装 HANA ODBC 驱动**，并在「ODBC 数据源(64 位)」中与 Python **位数一致**地配置好 DSN。

### 方式 A：双击脚本（推荐，自动装依赖）

将项目放到本机后，双击 **`run_windows.bat`**。脚本会：

1. 在项目目录创建虚拟环境 `.venv`（若尚无）  
2. 执行 `pip install -r requirements.txt`（安装 Flask、pyodbc、requests 等）  
3. 启动 `app.py`，默认监听 **http://127.0.0.1:5050**

然后在浏览器打开上述地址，**不要**用资源管理器双击打开 `templates\index.html`。

### 方式 B：命令行手动执行

```text
cd 项目目录
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

若出现 **`ModuleNotFoundError: No module named 'flask'`**，说明当前 Python 环境未安装依赖，请先执行：

```text
pip install -r requirements.txt
```

并确认运行 `python app.py` 时使用的是**已安装依赖**的解释器（例如已 `activate` 的 `.venv`）。

浏览器访问：`http://127.0.0.1:5050`  

可选环境变量：`FLASK_RUN_HOST`（默认 `0.0.0.0`）、`FLASK_RUN_PORT`（默认 `5050`）。

### 常见问题：点击「测试连接」出现 Failed to fetch

通常是因为用 **资源管理器双击打开了 `index.html`**，地址栏为 `file:///...`（`file://` 协议）。此时浏览器会把 `fetch('/api/...')` 当成本地磁盘路径（例如 `file:///D:/api/hana/test`），无法访问正在运行的 Flask，控制台里会出现 CORS / `net::ERR_FAILED` 等报错。

**正确做法：**先在项目目录执行 `python app.py`，再在浏览器中打开 **`http://127.0.0.1:5050`**（或你设置的主机与端口），不要直接双击打开模板文件。

若仍须以本地文件方式打开页面，须先启动后端，并在页面上方的红色提示区填写 **后端根地址**（如 `http://127.0.0.1:5050`）并保存；程序已为 `/api/*` 开启跨域，便于该场景调用。

---

## HTTP API 一览

| 方法 | 路径 | 说明 |
|------|------|------|
| `GET` | `/` | Web 界面 |
| `GET` | `/api/config` | 读取配置（密码与 Key 不回显，仅 `password_set` / `api_key_set`） |
| `POST` | `/api/config` | 保存配置（JSON：`hana`、`llm`；空密码/空 Key 表示保留原值） |
| `POST` | `/api/hana/test` | 测试 HANA；请求体可带完整 `hana`（及可选 `llm`）用于临时覆盖 |
| `POST` | `/api/llm/test` | 测试大模型 Chat Completions |
| `GET` | `/api/schemas` | 当前配置下的 Schema 列表 |
| `GET` | `/api/catalog/tables?schema=` | 指定 schema（A）下的表（`PUBLIC.TABLES`）；可选 `&search=`（B） |
| `GET` | `/api/catalog/views?schema=` | 视图（`PUBLIC.VIEWS`）；可选 `&search=` 在 `DEFINITION` 中匹配 |
| `GET` | `/api/catalog/procedures?schema=` | 存储过程（`PUBLIC.PROCEDURES`）；可选 `&search=` |
| `GET` | `/api/catalog/functions?schema=` | 函数（`PUBLIC.FUNCTIONS`）；可选 `&search=` |
| `GET` | `/api/catalog/table/{schema}/{name}/columns` | 表列信息 |
| `GET` | `/api/catalog/table/{schema}/{name}/preview?limit=` | 表数据预览 |
| `GET` | `/api/catalog/view/{schema}/{name}/preview?limit=` | 视图数据预览 |
| `GET` | `/api/catalog/procedure/{schema}/{name}` | 过程参数与定义（若有） |
| `GET` | `/api/catalog/function/{schema}/{name}` | 函数参数与定义（若有） |

---

## 安全提示

- `config.json` 含数据库密码与 LLM API Key，请限制文件权限，且不要提交到 Git。  
- 数据预览仅 `SELECT`，但仍在真实库上执行；应对接账号做 **最小权限**（例如只读业务 schema）。  
- 本服务默认监听 `0.0.0.0` 时，请注意网络边界与防火墙策略。
